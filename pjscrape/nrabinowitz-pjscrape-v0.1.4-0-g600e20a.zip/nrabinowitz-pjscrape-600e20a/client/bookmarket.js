javascript:(function(d,s){s=d.createElement('script');s.src='http://nrabinowitz.github.com/pjscrape/client/dev_harness.js';d.body.appendChild(s);})(document);
