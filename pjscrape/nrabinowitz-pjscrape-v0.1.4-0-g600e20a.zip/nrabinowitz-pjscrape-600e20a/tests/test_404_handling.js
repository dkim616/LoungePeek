pjs.addSuite({
    urls: [
        'http://localhost:8888/test_site/index.html',
        'http://localhost:8888/test_site/not-a-real-page.html'
    ],
    scraper: 'h1'
});