
pjs.addSuite({
    url: 'http://localhost:8888/test_site/page1.html',
    scraper: {
        async: true,
        scraper: function() {
            // do nothing
        }
    }
});